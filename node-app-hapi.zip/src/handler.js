const getStart = () => ({
    status: 'success',
    data: {
        message: 'halo',
    },
});

module.exports = { getStart };
